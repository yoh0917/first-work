echo 0 0 | gmt psxy -R-100/100/-100/100 -JX10 -Sc1 -Ba10g10/a10g10 -P > 01_psxy.ps

